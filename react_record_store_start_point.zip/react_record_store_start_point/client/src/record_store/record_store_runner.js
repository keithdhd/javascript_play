var RecordStore = require('./record_store.js');
var Record = require('./record.js');

var nevermind = new Record("Nirvana", "Nevermind", 9.99);
var cowboys   = new Record("Johnny Cash", "All My Friends Are Cowboys", 12.99);

var rockinRicks = new RecordStore("Rockin' Rick's", "New York");
rockinRicks.addRecord(cowboys);
rockinRicks.addRecord(nevermind);

console.log(rockinRicks);

console.log(rockinRicks.listInventory().listing);
console.log(rockinRicks.listInventory().totalPrice);
