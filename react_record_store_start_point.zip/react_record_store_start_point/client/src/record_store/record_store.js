function RecordStore(name, city){
  this.name       = name;
  this.city       = city;
  this.records    = [];
  this.cashInBank = 0;

  this.getName = function(){
    return this.name;
  }

  this.getCity = function(){
    return this.city;
  }

  this.getRecords = function(){
    return this.records;
  }

  this.addRecord = function(record){
    this.records.push(record);
  }

  this.sellRecord = function(record){
    //Find the correct Record in the array and remove it
    for (var i = 0; i < this.records.length; i++) {
      if(this.records[i].getTitle() === record.getTitle()){
        var soldRecord = this.records.splice(i, 1);
      }
    };

    //Add price to the balance
    this.setCashInBank(record.getPrice());
    return soldRecord[0];
  }

  this.getCashInBank = function(){
    return this.cashInBank;
  }

  this.setCashInBank = function(amount){
    this.cashInBank += amount;
  }

  this.listInventory = function(){
    var inventory = {
      listing: "",
      totalPrice: 0
    };
    var i = 0;
    for (i; i < this.records.length; i++) {
      inventory.listing += this.records[i].getTitle() + " by " + this.records[i].getArtist() + " price:$" + this.records[i].getPrice() + "\n";
      inventory.totalPrice += this.records[i].getPrice();
    };
    return inventory;
  }
}

module.exports = RecordStore;