var React = require('react');
var ReactDOM = require('react-dom');
var RecordStoreBox = require('./components/RecordStoreBox');

window.onload = function(){

  ReactDOM.render(
    <RecordStoreBox/>,
    document.getElementById('app')
  );

};