window.onload = function(){
  console.log("webpack app started");
};
