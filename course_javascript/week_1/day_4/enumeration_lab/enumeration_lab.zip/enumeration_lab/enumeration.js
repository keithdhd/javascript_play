var Enumeration = function() {}

Enumeration.prototype = {

  // your code here!

}

module.exports = Enumeration;